import { useState, useEffect } from 'react';
import axios from 'axios';

const API = 'http://localhost:8080/tasks';

function App() {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState({ title: '', description: '', status: 'Pending' });

  useEffect(() => { loadTasks(); }, []);

  const loadTasks = () => axios.get(API).then(r => setTasks(r.data)).catch(e => alert('Error loading tasks'));

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post(API, form)
      .then(() => {
        setForm({ title: '', description: '', status: 'Pending' });
        loadTasks();
      })
      .catch(e => alert('Error creating task'));
  };

  const updateStatus = (task) => {
    axios.put(`${API}/${task.id}`, { 
      ...task, 
      status: task.status === 'Pending' ? 'Completed' : 'Pending' 
    }).then(loadTasks).catch(e => alert('Error updating task'));
  };

  const deleteTask = (id) => {
    if (window.confirm('Delete this task?')) {
      axios.delete(`${API}/${id}`).then(loadTasks).catch(e => alert('Error deleting task'));
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '900px', margin: '0 auto', fontFamily: 'Arial' }}>
      <h1>Task Management System</h1>

      <form onSubmit={handleSubmit} style={{ marginBottom: '20px', padding: '15px', background: '#f5f5f5', borderRadius: '5px' }}>
        <input 
          placeholder="Title *" 
          value={form.title}
          onChange={e => setForm({...form, title: e.target.value})}
          required
          style={{ padding: '8px', marginRight: '10px', width: '200px', border: '1px solid #ddd', borderRadius: '3px' }}
        />
        <input 
          placeholder="Description" 
          value={form.description}
          onChange={e => setForm({...form, description: e.target.value})}
          style={{ padding: '8px', marginRight: '10px', width: '300px', border: '1px solid #ddd', borderRadius: '3px' }}
        />
        <button type="submit" style={{ padding: '8px 20px', background: '#007bff', color: 'white', border: 'none', borderRadius: '3px', cursor: 'pointer' }}>
          Add Task
        </button>
      </form>

      <table border="1" cellPadding="10" style={{ width: '100%', borderCollapse: 'collapse', background: 'white' }}>
        <thead>
          <tr style={{ background: '#007bff', color: 'white' }}>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Status</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tasks.length === 0 && (
            <tr>
              <td colSpan="6" style={{ textAlign: 'center', padding: '20px', color: '#999' }}>
                No tasks found. Add your first task above!
              </td>
            </tr>
          )}
          {tasks.map(task => (
            <tr key={task.id}>
              <td>{task.id}</td>
              <td><strong>{task.title}</strong></td>
              <td>{task.description || '-'}</td>
              <td>
                <span style={{
                  padding: '4px 10px',
                  borderRadius: '3px',
                  background: task.status === 'Pending' ? '#fff3cd' : '#d4edda',
                  color: task.status === 'Pending' ? '#856404' : '#155724',
                  fontSize: '12px'
                }}>
                  {task.status}
                </span>
              </td>
              <td style={{ fontSize: '12px', color: '#666' }}>
                {new Date(task.createdAt).toLocaleDateString()}
              </td>
              <td>
                <button 
                  onClick={() => updateStatus(task)} 
                  style={{ marginRight: '5px', padding: '5px 10px', cursor: 'pointer', background: '#28a745', color: 'white', border: 'none', borderRadius: '3px' }}
                >
                  Toggle
                </button>
                <button 
                  onClick={() => deleteTask(task.id)}
                  style={{ padding: '5px 10px', cursor: 'pointer', background: '#dc3545', color: 'white', border: 'none', borderRadius: '3px' }}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginTop: '20px', padding: '10px', background: '#f8f9fa', borderRadius: '5px', fontSize: '13px', color: '#666' }}>
        <strong>Total Tasks:</strong> {tasks.length} | 
        <strong> Pending:</strong> {tasks.filter(t => t.status === 'Pending').length} | 
        <strong> Completed:</strong> {tasks.filter(t => t.status === 'Completed').length}
      </div>
    </div>
  );
}

export default App;