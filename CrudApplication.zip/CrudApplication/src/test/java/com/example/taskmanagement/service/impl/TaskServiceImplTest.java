package com.example.taskmanagement.service.impl;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.taskmanagement.entity.Task;
import com.example.taskmanagement.repository.TaskRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TaskServiceImplTest {

  @Mock
  private TaskRepository taskRepository;

  @InjectMocks
  private TaskServiceImpl taskService;

  @Test
  void createTask_ShouldSaveTask() {
    Task task = new Task();
    task.setTitle("Test");
    task.setStatus("Pending");

    when(taskRepository.save(any(Task.class))).thenReturn(task);

    Task result = taskService.createTask(task);

    assertNotNull(result);
    verify(taskRepository).save(any(Task.class));
  }

  @Test
  void getTaskById_WhenExists_ShouldReturnTask() {
    Task task = new Task();
    task.setId(1L);
    when(taskRepository.findById(1L)).thenReturn(Optional.of(task));

    Optional<Task> result = taskService.getTaskById(1L);

    assertTrue(result.isPresent());
    assertEquals(1L, result.get().getId());
  }

  @Test
  void deleteTask_WhenExists_ShouldReturnTrue() {
    when(taskRepository.existsById(1L)).thenReturn(true);

    boolean result = taskService.deleteTask(1L);

    assertTrue(result);
    verify(taskRepository).deleteById(1L);
  }
}