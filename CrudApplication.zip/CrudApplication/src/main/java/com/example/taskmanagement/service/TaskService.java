package com.example.taskmanagement.service;

import java.util.List;
import java.util.Optional;

import com.example.taskmanagement.entity.Task;

public interface TaskService {

  List<Task> getAllTasks();

  Optional<Task> getTaskById(Long id);

  Task createTask(Task task);

  Optional<Task> updateTask(Long id, Task task);

  boolean deleteTask(Long id);
}