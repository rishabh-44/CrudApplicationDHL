package com.example.taskmanagement.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.taskmanagement.entity.Task;
import com.example.taskmanagement.repository.TaskRepository;
import com.example.taskmanagement.service.TaskService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TaskServiceImpl implements TaskService {

  private final TaskRepository taskRepository;

  @Override
  public List<Task> getAllTasks() {
    return taskRepository.findAll();
  }

  @Override
  public Optional<Task> getTaskById(Long id) {
    return taskRepository.findById(id);
  }

  @Override
  public Task createTask(Task task) {
    task.setId(null);
    if (task.getStatus() == null || task.getStatus().isEmpty()) {
      task.setStatus("Pending");
    }
    return taskRepository.save(task);
  }

  @Override
  public Optional<Task> updateTask(Long id, Task task) {
    return taskRepository.findById(id).map(existing -> {
      existing.setTitle(task.getTitle());
      existing.setDescription(task.getDescription());
      existing.setStatus(task.getStatus());
      return taskRepository.save(existing);
    });
  }

  @Override
  public boolean deleteTask(Long id) {
    if (taskRepository.existsById(id)) {
      taskRepository.deleteById(id);
      return true;
    }
    return false;
  }
}